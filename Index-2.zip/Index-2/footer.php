<!-- footer.php -->
<footer>
    <p>Developed By <a href="https://facebook.com/safnimj" target="_blank">SAFNI mj</a></p>
</footer>
<link rel="stylesheet" type="text/css" href="styles.css">